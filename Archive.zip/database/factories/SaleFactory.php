<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Sale;
use Faker\Generator as Faker;

$factory->define(Sale::class, function (Faker $faker) {
    return [
        //
    ];
});
