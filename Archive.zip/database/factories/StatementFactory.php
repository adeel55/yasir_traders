<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Statement;
use Faker\Generator as Faker;

$factory->define(Statement::class, function (Faker $faker) {
    return [
        //
    ];
});
