<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\OrderBooker;
use Faker\Generator as Faker;

$factory->define(OrderBooker::class, function (Faker $faker) {
    return [
        //
    ];
});
