<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\SaleMan;
use Faker\Generator as Faker;

$factory->define(SaleMan::class, function (Faker $faker) {
    return [
        //
    ];
});
