<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleMan extends Model
{
    protected $fillable = ['name','phone'];
}
