<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Yasir Traders</title>

        <!-- Fonts -->
         <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
         <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700,400italic">
        <link rel="stylesheet" href="<?php echo e(asset('fonts/material_fonts/icon.css')); ?>">
        <link href="<?php echo e(asset('fontawesome-free-5.9.0/css/all.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div id="app"></div>
        <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/yasir_traders/resources/views/welcome.blade.php ENDPATH**/ ?>