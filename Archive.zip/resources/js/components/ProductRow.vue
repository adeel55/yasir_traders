<template>
  <div>
    <md-button @click="addRow" class="md-fab md-btn-fab md-mini md-primary" style="float: right">
      <md-icon>playlist_add</md-icon>
    </md-button>
    <div class="md-layout" v-for="(row, index) in productrows" :key="index">
       <div class="md-layout-item md-small-size-100 md-size-40">
        <md-autocomplete
          v-model="row.company"
          :md-options="companies"
          @md-changed="searchCompanies"
          md-input-max-length="50"
          autocomplete="off"
          md-dense>
          <label>Company</label>
        </md-autocomplete>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-40">
        <md-autocomplete
          v-model="row.product"
          :md-options="products"
          @md-changed="searchProducts"
          @md-opened="searchProducts"
          md-input-max-length="50"
          md-dense>
          <label>Product</label>
        </md-autocomplete>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-20">
         <md-field>
           <label>Qty</label>
           <md-input v-model="row.qty" type="number"></md-input>
         </md-field>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-20">
         <md-field>
           <label>Carton</label>
           <md-input v-model="row.carton" type="number"></md-input>
         </md-field>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-25">
         <md-field>
           <label>Purchase</label>
           <md-input v-model="row.unit_purchse_price" type="number"></md-input>
         </md-field>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-25">
         <md-field>
           <label>Unit Sale</label>
           <md-input v-model="row.unit_sale_price" type="number"></md-input>
         </md-field>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-20">
         <md-field>
           <label>Expire</label>
           <md-input v-model="row.expire" type="date"></md-input>
           <!-- <md-datepicker v-model="row.selectedDate"/> -->
         </md-field>
       </div>
       <div class="md-layout-item md-small-size-100 md-size-10">
        <md-button @click="removeRow(index)" class="md-fab md-btn-fab md-mini md-danger">
           <md-icon>delete</md-icon>
        </md-button>
       </div>
       <md-divider class="hr-divider"></md-divider>
    </div>
    <md-dialog-confirm
      :md-active.sync="active"
      md-title="Confirm"
      md-content="Are you sure to add these stock into inventory?"
      md-confirm-text="Yes"
      md-cancel-text="Cancel"
      @md-cancel="onCancel"
      @md-confirm="save" />
 
    <md-button @click="active = true" class="md-success">Save</md-button>
    <md-dialog-alert
      :md-active.sync="success"
      md-title="Success"
      md-content="Stock saved succesfully." />
    <md-dialog-alert
      :md-active.sync="fail"
      md-title="Failed"
      md-content="Stock failed to add." />
  </div>
</template>
<script>
  export default {
    name: "ProductRow",
    prop: {
    },
    data :() => {
      return {
        
        productrows: [{'company':null,'product':null,'qty':null,'carton':null,'expire':null,'unit_purchse_price':null,'unit_sale_price':null,'expire':null}],
        companieslist: [],
        companies: [],
        productlist: [],
        products: [],
        active: false,
        success: false,
        fail: false,
        selectedDate: new Date('2018/03/26')
      };
    },
    mounted() {
      // Fetch initial 
    },
    methods: {
      searchCompanies (searchTerm) {
        axios.get('/search_companies?searchString='+searchTerm)
        .then(d => this.companieslist = d.data)
        .catch(err => console.log(err));

        this.companies = new Promise(resolve => {
          window.setTimeout(() => {
            if (!searchTerm) {
              resolve(this.companieslist)
            } else {
              const term = searchTerm.toLowerCase()

              resolve(this.companieslist.filter(( name ) => name.toLowerCase().includes(term)))
            }
          }, 500)
        })
      },
      searchProducts(searchTerm){
        axios.get('/search_products?searchString='+searchTerm)
              .then(d => {this.productlist = d.data;})
              .catch(err => console.log(err));

        

        this.products = new Promise(resolve => {
          window.setTimeout(() => {
            if (!searchTerm) {
              resolve(this.productlist)
            } else {
              const term = searchTerm.toLowerCase()

              resolve(this.productlist.filter(( name ) => name.toLowerCase().includes(term)))
            }
          },500)
        })
      },
      addRow(a){
        this.productrows.push({
          company: null,
          product: null,
          qty: null,
          carton: null,
          expire: null,
          unit_purchse_price: null,
          unit_sale_price: null
        })
      },
      removeRow (rowId) {
        this.productrows.splice(rowId, 1)
      },
      save () {
        axios.post('/inventory',{'productrows':this.productrows})
        .then(d => {})
        .catch(err => console.log(err));
        this.success=true;
      },
      onCancel(){

      }
    },
    created(){
      
    }
  };
</script>
<style type="scss" scoped>
  .hr-divider{
    border-top: 2px dashed #aaa;
    width: 100%;
  }
</style>